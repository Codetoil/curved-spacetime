#!/bin/sh
./apache-maven-3.9.9/bin/mvn install
read -p "Please press ENTER to exit."