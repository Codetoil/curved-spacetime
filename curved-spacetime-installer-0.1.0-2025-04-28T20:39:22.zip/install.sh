#!/bin/sh
./apache-maven-3.9.9/bin/mvn -q install
echo "Please press ENTER to exit."
read dummyVar