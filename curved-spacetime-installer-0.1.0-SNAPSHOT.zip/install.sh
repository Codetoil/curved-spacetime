#!/bin/sh
./apache-maven-3.9.9/bin/mvn -q -U install
echo "Please press ENTER to exit."
read dummyVar